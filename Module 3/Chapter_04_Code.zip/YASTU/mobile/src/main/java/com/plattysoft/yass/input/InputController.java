package com.plattysoft.yass.input;

/**
 * Created by Raul Portales on 10/03/15.
 */
public class InputController {

    public double mHorizontalFactor;
    public double mVerticalFactor;

    public boolean mIsFiring;

    public void onStart() {
    }

    public void onStop() {
    }

    public void onPause() {
    }

    public void onResume() {
    }

    public void onPreUpdate() {
    }
}

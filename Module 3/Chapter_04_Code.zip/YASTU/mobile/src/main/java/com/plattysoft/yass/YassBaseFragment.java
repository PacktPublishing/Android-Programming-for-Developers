package com.plattysoft.yass;

import android.app.Fragment;

/**
 * Created by Raul Portales on 06/03/15.
 */
public class YassBaseFragment extends Fragment {

    public boolean onBackPressed() {
        return false;
    }

    protected YassActivity getYassActivity() {
        return (YassActivity) getActivity();
    }
}

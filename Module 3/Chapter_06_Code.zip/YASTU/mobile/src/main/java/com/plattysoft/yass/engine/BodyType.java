package com.plattysoft.yass.engine;

/**
 * Created by Raul Portales on 31/03/15.
 */
public enum BodyType {
    None,
    Circular,
    Rectangular
}
